package guia5;

import java.io.File;
import static java.lang.Integer.parseInt;
import java.util.LinkedList;
import javax.swing.table.DefaultTableModel;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;
import javax.swing.ImageIcon;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;


public class datos extends javax.swing.JFrame {
    LinkedList notas = new LinkedList<>();
    String nombre = "";
    double aprobo = 0, reprobo = 0;
    double totalestudiantes;

    

    
    
    public static void graficaestudiante(String nombre, LinkedList<Double> notas) {
        DefaultCategoryDataset datos = new DefaultCategoryDataset();
        int CantidadNotas = notas.size();
            for (int i = 0; i < CantidadNotas; i++) {
             int a = i + 1;
                Double ValorNota = notas.get(i);
                datos.setValue(ValorNota, "Profit", Integer.toString(a));
                }
        JFreeChart chart = ChartFactory.createBarChart(nombre, "Nota", "Valor", datos, PlotOrientation.VERTICAL,
                false, 
                true, 
                false
        );

        try {
            ChartUtilities.saveChartAsJPEG(new File("alumno.jpg"), chart, 500, 300);
        } catch (IOException e) {
            System.err.println("No se ha generado la grafica");
            e.printStackTrace();
        }
    }

    public static void circular(double promovido, double reprobado, double total) {
        double porcentajeaprob = (promovido / total) * 100;
        double porcentajereprob = (reprobado / total) * 100;
        DefaultPieDataset datostorta = new DefaultPieDataset();
        datostorta.setValue("Estudiantes aprobados " + porcentajeaprob + "%", porcentajeaprob);
        datostorta.setValue("Estudiantes reprobados " + porcentajereprob + "%", porcentajereprob);
        JFreeChart chart = ChartFactory.createPieChart("Tasa de aprobacion", 
                datostorta, 
                true, 
                true, 
                false 
        );
        try {
            ChartUtilities.saveChartAsJPEG(new File("circular.jpg"), chart, 500, 300);
        } catch (Exception e) {
            System.out.println("Problem occurred creating chart.");
        }
    }

    public datos() {
        
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        datosTabla = new javax.swing.JFileChooser();
        torta = new javax.swing.JLabel();
        historic = new javax.swing.JLabel();
        tablanotas = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        estudiantes = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        numeronotas = new javax.swing.JTextArea();
        crear = new javax.swing.JButton();
        importar = new javax.swing.JButton();
        calcular = new javax.swing.JButton();
        grafico = new javax.swing.JButton();
        nombrehistorico = new javax.swing.JTextArea();
        mostrar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        export = new javax.swing.JButton();
        resultado = new javax.swing.JScrollPane();
        tablaDefinitivas = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();

        datosTabla.setBackground(java.awt.Color.lightGray);
        try {
            // Establecer el Look and Feel del sistema
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        FileFilter filter = new FileFilter() {
            public boolean accept(File file) {
                // Aceptar todos los directorios y archivos .csv
                return file.isDirectory() || file.getName().toLowerCase().endsWith(".csv");
            }

            public String getDescription() {
                // Descripción del filtro
                return "Archivos CSV (*.csv)";
            }
        };

        // Aplicar el filtro al JFileChooser
        datosTabla.setFileFilter(filter);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        torta.setPreferredSize(new java.awt.Dimension(500, 300));

        historic.setPreferredSize(new java.awt.Dimension(500, 300));

        jTable1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jTable1.setToolTipText("");
        jTable1.setColumnSelectionAllowed(true);
        jTable1.setShowGrid(true);
        tablanotas.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        jLabel1.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel1.setText("Cantidad de estudiantes: ");

        estudiantes.setColumns(20);
        estudiantes.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        estudiantes.setRows(5);
        estudiantes.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        estudiantes.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setText("Cantidad de notas: ");

        numeronotas.setColumns(20);
        numeronotas.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        numeronotas.setRows(5);
        numeronotas.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        crear.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        crear.setText("Crear Tabla");
        crear.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        crear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                crearActionPerformed(evt);
            }
        });
        crear.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                crearKeyPressed(evt);
            }
        });

        importar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        importar.setText("Insertar tabla");
        importar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        importar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                importarActionPerformed(evt);
            }
        });

        calcular.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        calcular.setText("Calcular Definitivas");
        calcular.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        calcular.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        calcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                calcularActionPerformed(evt);
            }
        });

        grafico.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        grafico.setText("Datos alumno");
        grafico.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        grafico.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        grafico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                graficoActionPerformed(evt);
            }
        });

        nombrehistorico.setColumns(20);
        nombrehistorico.setRows(5);
        nombrehistorico.setToolTipText("Nombre estudiante");
        nombrehistorico.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        mostrar.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        mostrar.setText("Mostrar resultados");
        mostrar.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        mostrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel3.setText("Nombre estudiante:");

        export.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        export.setText("Exportar Tablas");
        export.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        export.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportActionPerformed(evt);
            }
        });

        tablaDefinitivas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nombre", "Definitiva", "Resultado"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Double.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tablaDefinitivas.setShowHorizontalLines(true);
        resultado.setViewportView(tablaDefinitivas);

        jLabel4.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("DATOS DE ESTUDIANTES");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(torta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(historic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(74, 74, 74))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(59, 59, 59)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(numeronotas, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(estudiantes, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(31, 31, 31)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel1)
                                            .addComponent(mostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(16, 16, 16)
                                                .addComponent(grafico, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(61, 61, 61)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(resultado, javax.swing.GroupLayout.DEFAULT_SIZE, 486, Short.MAX_VALUE)
                            .addComponent(tablanotas)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(311, 311, 311)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(115, 115, 115)
                                .addComponent(jLabel3))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(importar, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(116, 116, 116)
                                .addComponent(export, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(82, 82, 82)
                                .addComponent(nombrehistorico, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(279, 279, 279)
                        .addComponent(crear, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(193, 193, 193)
                        .addComponent(calcular))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(330, 330, 330)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(estudiantes, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(24, 24, 24)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(numeronotas, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(mostrar, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(grafico))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(9, Short.MAX_VALUE)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tablanotas, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(crear)
                            .addComponent(calcular))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(resultado, javax.swing.GroupLayout.PREFERRED_SIZE, 196, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(nombrehistorico, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(importar, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(export, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(historic, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addComponent(torta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportActionPerformed

    DefaultTableModel definitivas = (DefaultTableModel) tablaDefinitivas.getModel();//instancia el modelo de la tabla de definitivas
    DefaultTableModel calificaciones = (DefaultTableModel) jTable1.getModel();
                try (FileWriter writer = new FileWriter("tablas.csv")) {
            // Escribir datos de la tabla de calificaciones
                 for (int colum = 0; colum < calificaciones.getColumnCount(); colum++) {
                writer.write(calificaciones.getColumnName(colum) + ",");
                 }
                 writer.write("\n");
                for (int fila = 0; fila < calificaciones.getRowCount(); fila++) {
                for (int colum = 0; colum < calificaciones.getColumnCount(); colum++) {
                    writer.write(calificaciones.getValueAt(fila, colum).toString() + ",");
                }
                writer.write("\n");
                 }
                 writer.write("\n");

            // Escribir datos de la tabla de definitivas
            for (int colum = 0; colum < definitivas.getColumnCount(); colum++) {
                writer.write(definitivas.getColumnName(colum) + ",");
            }
            writer.write("\n");

            for (int fila = 0; fila < definitivas.getRowCount(); fila++) {
                for (int colum = 0; colum < definitivas.getColumnCount(); colum++) {
                    writer.write(definitivas.getValueAt(fila, colum).toString() + ",");
                }
                writer.write("\n");
            }
            System.out.println("Exportación de datos exitosa");
        } catch (IOException e) {
            System.err.println("Error al exportar datos: " + e.getMessage());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_exportActionPerformed

    private void mostrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarActionPerformed
        DefaultTableModel calificaciones = (DefaultTableModel) jTable1.getModel();
        int conteoErrores = 0;
        notas.clear();

        for (int indiceFila = 0; indiceFila < calificaciones.getRowCount(); indiceFila++) {
        if (calificaciones.getValueAt(indiceFila, 0).toString().equals(nombrehistorico.getText())) {
            nombre = calificaciones.getValueAt(indiceFila, 0).toString();
        
            for (int indiceColumna = 1; indiceColumna < calificaciones.getColumnCount(); indiceColumna++) {
            try {
                Double valorNota = Double.valueOf(calificaciones.getValueAt(indiceFila, indiceColumna).toString());
                notas.add(valorNota);
            } catch (NumberFormatException e) {
                System.err.println("Error: No se pudo procesar el dato");
                e.printStackTrace();
            }
        }
    } else {
        conteoErrores++;
    }
    if (conteoErrores == calificaciones.getRowCount()) {
        error ventanaError = new error(this, true);
        ventanaError.setVisible(true);
        nombrehistorico.setText("");
    }
}
        graficaestudiante(nombre, notas); 
        ImageIcon imagenEstudiante = new ImageIcon("alumno.jpg");
        imagenEstudiante.getImage().flush();
        this.historic.setIcon(imagenEstudiante);
    }//GEN-LAST:event_mostrarActionPerformed

    private void calcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_calcularActionPerformed
        DefaultTableModel calificaciones = (DefaultTableModel) jTable1.getModel();
        DefaultTableModel definitivas = (DefaultTableModel) tablaDefinitivas.getModel();
            try {
                for (int fila = 0;  fila < calificaciones.getRowCount(); fila++) {
                    double suma = 0;
                    String nombre = calificaciones.getValueAt(fila, 0).toString();
                    for (int colum = 1; colum < calificaciones.getColumnCount(); colum++) {
                        double nota = Double.parseDouble(calificaciones.getValueAt(fila, colum).toString());
                        if (nota > 5) throw new Exception("La nota ingresada es invalida");
                        suma += nota;
                    }
                    double definitiva = suma / (calificaciones.getColumnCount() - 1);
                    String paso = (definitiva >= 3.0) ? "APROBO" : "REPROBO";
                    if (definitiva >= 3.0) aprobo++;
                    else reprobo++;
                    definitivas.addRow(new Object[]{nombre, definitiva, paso});
                }
                totalestudiantes = calificaciones.getRowCount();
            } catch (Exception e) {
                System.err.println("Hubo un problema al calcular definitivas");
                e.printStackTrace();
            }
    }//GEN-LAST:event_calcularActionPerformed

    private void importarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_importarActionPerformed
        
            JFileChooser escogerArchivo = new JFileChooser();
            DefaultTableModel calificaciones = (DefaultTableModel) jTable1.getModel();
            int returnValue = escogerArchivo.showOpenDialog(null);
            if (returnValue == JFileChooser.APPROVE_OPTION) {
                File archivo = escogerArchivo.getSelectedFile();
                try {
                    Scanner entrada = new Scanner(archivo);
                    String[] est = null;
                    boolean agg = false;
                    entrada.nextLine();
                    while (entrada.hasNext()) {
                        String linea = entrada.nextLine();
                        if (linea.contains(";")) {
                            est = linea.split(";");
                        } else if (linea.contains(",")) {
                            est = linea.split(",");
                        }
                        if (!agg) {
                            calificaciones.addColumn("Nombre:");
                            for (int i = 1; i < est.length; i++) {
                                calificaciones.addColumn("Nota " + i);
                            }
                            agg = true;
                        }
                        calificaciones.addRow(est);
                    }
                } catch (FileNotFoundException ex) {
                    Logger.getLogger(datos.class.getName()).log(Level.SEVERE, null, ex);
                    ex.printStackTrace();
                }
            }
    }//GEN-LAST:event_importarActionPerformed

    private void crearKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_crearKeyPressed

    }//GEN-LAST:event_crearKeyPressed

    private void crearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_crearActionPerformed
                    DefaultTableModel calificaciones = (DefaultTableModel) jTable1.getModel();
             try {
                 int est = Integer.parseInt(estudiantes.getText()), not = Integer.parseInt(numeronotas.getText());
                 calificaciones.addColumn("Nombre");
                 calificaciones.setRowCount(est);
                 for (int b = 1; b <= not; b++) calificaciones.addColumn("Nota: " + b);
             } catch (Exception e) {
                 System.err.println("Hubo un problema al crear la tabla");
                 estudiantes.setText("");
                 numeronotas.setText("");
                 e.printStackTrace();
             }
    }//GEN-LAST:event_crearActionPerformed

    private void graficoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_graficoActionPerformed
        circular(aprobo, reprobo, totalestudiantes);
        ImageIcon ImagenTorta = new ImageIcon("circular.jpg");
        ImagenTorta.getImage().flush();
        this.torta.setIcon(ImagenTorta);
    }//GEN-LAST:event_graficoActionPerformed
 
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new datos().setVisible(true);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton calcular;
    private javax.swing.JButton crear;
    private javax.swing.JFileChooser datosTabla;
    private javax.swing.JTextArea estudiantes;
    private javax.swing.JButton export;
    private javax.swing.JButton grafico;
    private javax.swing.JLabel historic;
    private javax.swing.JButton importar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton mostrar;
    private javax.swing.JTextArea nombrehistorico;
    private javax.swing.JTextArea numeronotas;
    private javax.swing.JScrollPane resultado;
    private javax.swing.JTable tablaDefinitivas;
    private javax.swing.JScrollPane tablanotas;
    private javax.swing.JLabel torta;
    // End of variables declaration//GEN-END:variables


}
